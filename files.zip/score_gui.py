"""Pontszám-kijelző GUI, pygame-mel, framebuffer/DRM kimenetre.

PC-n (VS Code-ban) teszteléskor sima ablakban fut, mert az
SDL_VIDEODRIVER=kmsdrm driver ott nem elérhető, SDL automatikusan
a normál ablakos módra esik vissza.

A Raspberry Pi-n explicit kmsdrm driverre állítva direktben a
framebufferre/DRM-re rajzol, X11/Wayland nélkül.
"""

import pygame
import os

os.environ.setdefault("SDL_VIDEODRIVER", "kmsdrm")


class ScoreGUI:
    """
    A pontszám-kijelző alap képernyő. Mindig kész állapotban van,
    csak akkor rajzol, ha a state machine SCORE állapotban van.

    A kijelzőt (DRM master jogot) fel- és leengedi az
    acquire_display() / release_display() hívásokkal, hogy az mpv
    VIDEO állapotban kizárólagosan birtokolhassa a DRM kimenetet.
    """

    SCREEN_W = 800
    SCREEN_H = 600

    COLOR_BG = (10, 10, 15)
    COLOR_TEXT = (240, 240, 240)
    COLOR_ACTIVE = (255, 180, 40)
    COLOR_INACTIVE = (120, 120, 130)
    COLOR_MULTIBALL = (220, 40, 40)

    def __init__(self):
        self.screen = None
        self.font_score_big = None
        self.font_label = None
        self.font_small = None
        self.active = False

    def acquire_display(self):
        """
        Felveszi a kijelzőt (DRM master jogot). Csak akkor hívjuk,
        amikor SCORE állapotba lépünk, hogy az mpv addigra már
        elengedte a DRM-et.
        """
        if self.active:
            return

        pygame.init()
        self.screen = pygame.display.set_mode(
            (self.SCREEN_W, self.SCREEN_H),
            pygame.FULLSCREEN if os.environ.get("SDL_VIDEODRIVER") == "kmsdrm" else 0
        )
        pygame.display.set_caption("Cheech & Chong Pinball - Score")

        self.font_score_big = pygame.font.SysFont("Arial", 72, bold=True)
        self.font_label = pygame.font.SysFont("Arial", 28)
        self.font_small = pygame.font.SysFont("Arial", 22)
        self.active = True

    def release_display(self):
        """
        Elengedi a kijelzőt (DRM master jog felszabadítása), hogy
        az mpv tudjon rajzolni VIDEO állapotban.
        """
        if not self.active:
            return
        pygame.display.quit()
        pygame.quit()
        self.active = False

    def render(self, state):
        if not self.active:
            return  # biztonsági korlát: ne próbáljon rajzolni, ha nincs kijelző

        self.screen.fill(self.COLOR_BG)

        positions = [(40, 40), (420, 40), (40, 320), (420, 320)]
        for player_num, pos in zip(self.players_order(), positions):
            is_active = (player_num == state.current_player)
            color = self.COLOR_ACTIVE if is_active else self.COLOR_INACTIVE

            label = self.font_label.render(f"PLAYER {player_num}", True, color)
            self.screen.blit(label, pos)

            score_text = self.font_score_big.render(
                f"{state.players[player_num]:,}", True, color
            )
            self.screen.blit(score_text, (pos[0], pos[1] + 35))

        ball_text = self.font_small.render(f"BALL {state.current_ball}", True, self.COLOR_TEXT)
        self.screen.blit(ball_text, (40, 560 - 30))

        if state.multiball_active:
            mb_text = self.font_small.render("MULTIBALL!", True, self.COLOR_MULTIBALL)
            self.screen.blit(mb_text, (650, 560 - 30))

        pygame.display.flip()

    def players_order(self):
        return [1, 2, 3, 4]

    def handle_pygame_events(self):
        """
        Le kell kezelni a pygame eseménysorát, különben az event queue
        megtelik és a rendszer akadni kezd. Itt csak a QUIT-et nézzük
        (pl. Ctrl+C, vagy ha valaha lesz debug-billentyű).
        """
        if not self.active:
            return True
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
        return True
