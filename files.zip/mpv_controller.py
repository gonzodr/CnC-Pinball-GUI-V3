"""mpv IPC vezérlés: háttérben futó mpv process indítása és irányítása socket-en."""

import socket
import json
import os
import subprocess
import time


class MpvController:
    """
    Az mpv-t egy mindig futó, háttérben idle-ben várakozó process-ként
    kezeli, JSON IPC socketen küldött parancsokkal vezéreljük.

    Ez azért fontos, mert ha minden videónál újraindítanánk az mpv-t,
    a process-indítás (néhány száz ms) jelentős, érezhető késleltetést
    okozna a trigger és a videó megjelenése között.
    """

    SOCKET_PATH = "/tmp/mpv-socket"
    VIDEO_DIR = "/home/pi/videos"  # ide kerülnek a konvertált .mp4 fájlok

    def __init__(self):
        self._proc = None
        self._sock = None

    def start(self):
        """Elindítja az mpv-t idle módban, framebuffer/DRM kimenetre."""
        if os.path.exists(self.SOCKET_PATH):
            os.remove(self.SOCKET_PATH)

        self._proc = subprocess.Popen([
            "mpv",
            "--idle=yes",                   # ne lépjen ki, ha nincs mit lejátszani
            "--vo=drm",                     # direkt framebuffer/DRM-KMS kimenet, nincs X
            "--drm-connector=HDMI-A-1",      # allitsd a tenyleges csatlakozora (lsdrm-mel checkelheted)
            "--fullscreen",
            "--no-osc",                     # ne legyen kezelőfelület-overlay
            "--no-input-default-bindings",
            "--input-ipc-server=" + self.SOCKET_PATH,
            "--keep-open=no",               # videó vége után ne fagyjon az utolsó képkockán
        ])

        # várjuk meg, amíg a socket létrejön (mpv indítása után pár tized mp)
        for _ in range(50):
            if os.path.exists(self.SOCKET_PATH):
                break
            time.sleep(0.1)

        self._connect()

    def _connect(self):
        self._sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self._sock.connect(self.SOCKET_PATH)
        self._sock.settimeout(0.1)  # nem-blokkoló jellegű olvasáshoz

    def _send(self, command):
        """Egy IPC parancsot küld az mpv-nek."""
        if not self._sock:
            return
        payload = json.dumps({"command": command}) + "\n"
        try:
            self._sock.sendall(payload.encode("utf-8"))
        except (BrokenPipeError, OSError):
            print("[mpv] socket megszakadt, ujracsatlakozas")
            self._connect()

    def play(self, video_name: str):
        """Betölti és azonnal lejátssza a megadott videót."""
        path = os.path.join(self.VIDEO_DIR, video_name)
        if not path.endswith(".mp4"):
            path += ".mp4"
        self._send(["loadfile", path, "replace"])

    def stop(self):
        """Leállítja a lejátszást, visszamegy idle (fekete) állapotba."""
        self._send(["stop"])

    def is_finished(self) -> bool:
        """
        Lekérdezi, hogy véget ért-e a jelenlegi videó.
        Az 'eof-reached' property-t nézzük.
        """
        if not self._sock:
            return False
        request = json.dumps({
            "command": ["get_property", "eof-reached"],
            "request_id": 1
        }) + "\n"
        try:
            self._sock.sendall(request.encode("utf-8"))
            response = self._sock.recv(4096).decode("utf-8")
            for line in response.strip().split("\n"):
                if not line:
                    continue
                data = json.loads(line)
                if data.get("request_id") == 1:
                    return data.get("data", False) is True
        except (socket.timeout, OSError, json.JSONDecodeError):
            pass
        return False

    def shutdown(self):
        if self._sock:
            self._sock.close()
        if self._proc:
            self._proc.terminate()
