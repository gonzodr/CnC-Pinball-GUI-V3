"""Cheech & Chong Pinball - Raspberry Pi GUI/video vezerlo.

A teljes szoftver belepesi pontja: osszekoti a soros olvasot,
az allapotgepet, az mpv vezerlot es a pontszam-GUI-t egyetlen
futo event loopba.
"""

import time
import sys

from serial_reader import SerialReader
from state_machine import StateMachine, AppState
from mpv_controller import MpvController
from score_gui import ScoreGUI


# --- Konfiguracio ---
SERIAL_PORT = "/dev/ttyACM0"   # ellenorizd a Pi-n: `ls /dev/ttyACM*` vagy `/dev/ttyUSB*`
SERIAL_BAUDRATE = 115200
TARGET_FPS = 30                # 30 FPS bovven eleg egy pontszam-GUI-hoz


def main():
    print("[main] inditas...")

    mpv = MpvController()
    mpv.start()

    state = StateMachine(mpv)

    gui = ScoreGUI()
    gui.acquire_display()   # induláskor SCORE állapotban vagyunk, GUI kapja a kijelzőt

    serial_reader = SerialReader(SERIAL_PORT, SERIAL_BAUDRATE)
    serial_reader.start()

    clock_interval = 1.0 / TARGET_FPS
    running = True

    try:
        while running:
            loop_start = time.time()

            # 1. Soros parancsok feldolgozasa (nem blokkol, queue-bol olvas)
            for event in serial_reader.poll_events():
                state.handle_event(event)

            # 2. Video-vege detektalas (ha VIDEO allapotban vagyunk)
            state.tick()

            # 3. Allapotvaltas kezelese: DRM kijelzo atadasa
            transition = state.consume_transition()
            if transition:
                old_state, new_state = transition
                print(f"[main] allapotvaltas: {old_state.name} -> {new_state.name}")

                if new_state == AppState.VIDEO:
                    # GUI elengedi a kijelzot, mpv mar a play()-nel elindult lejatszani
                    gui.release_display()
                elif new_state == AppState.SCORE:
                    # mpv mar leallt/elfogyott a video, GUI visszaveszi a kijelzot
                    gui.acquire_display()

            # 4. Rajzolas, ha SCORE allapotban vagyunk
            if state.state == AppState.SCORE:
                running = gui.handle_pygame_events()
                gui.render(state)

            # 5. Frame-utemezes tartasa (ne porgessuk feleslegesen a CPU-t)
            elapsed = time.time() - loop_start
            sleep_time = clock_interval - elapsed
            if sleep_time > 0:
                time.sleep(sleep_time)

    except KeyboardInterrupt:
        print("[main] Ctrl+C, leallas...")

    finally:
        print("[main] takaritas...")
        serial_reader.stop()
        gui.release_display()
        mpv.shutdown()
        sys.exit(0)


if __name__ == "__main__":
    main()
