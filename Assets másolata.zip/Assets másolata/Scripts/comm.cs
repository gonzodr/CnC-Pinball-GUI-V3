﻿using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using UnityEngine;
using UnityEngine.UI;
using System.IO.Ports;
using System;
using UnityEngine.SceneManagement;

public class comm : MonoBehaviour
{
    SerialPort mySPort = new SerialPort("COM5", 9600);
    private string IncomeMsg = "";
    public string msgs;
    // Start is called before the first frame update
    void Start()
    {
        mySPort.Open();
        mySPort.ReadTimeout = 45;
    }

    // Update is called once per frame
    void Update()
    {
        if (mySPort.IsOpen)  //youtube tutorial's method 
        {
            try
            {

                // do other stuff with the data
                OnserialEvent();
            }
            catch (TimeoutException e)
            {
                // no-op, just to silence the timeouts. 
                // (my arduino sends 12-16 byte packets every 0.1 secs)
            }
        }
        if (Input.GetKey("escape"))
        {
            Application.Quit();
        }
    }
    void OnserialEvent()
    {
        IncomeMsg = mySPort.ReadLine();
        if (mySPort.ReadLine() != "")
        {
            
                SceneManager.LoadScene(1);
            

        }
    }
}