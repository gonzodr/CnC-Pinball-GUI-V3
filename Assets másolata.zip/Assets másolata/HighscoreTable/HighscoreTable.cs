﻿/* 
    ------------------- Code Monkey -------------------

    Thank you for downloading this package
    I hope you find it useful in your projects
    If you have any questions let me know
    Cheers!

               unitycodemonkey.com
    --------------------------------------------------
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using CodeMonkey.Utils;

public class HighscoreTable : MonoBehaviour {
    CamTimer kuki;
    private Transform entryContainer;
    private Transform entryTemplate;
    private List<Transform> highscoreEntryTransformList;
    public Text FirstNameText;
    public Text SecondNameText;
    public Text ThirdNameText;
    public Text ForthNameText;
    public Text FifthNameText;
    public Text SixthNameText;
    public Text SeventhNameText;
    public Text EightNameText;
    public Text NinethNameText;
    public Text TenthNameText;
    public Text FirstScoreText;
    public Text SecondScoreText;
    public Text ThirdScoreText;
    public Text ForthScoreText;
    public Text FifthScoreText;
    public Text SixthScoreText;
    public Text SeventhScoreText;
    public Text EightScoreText;
    public Text NinethScoreText;
    public Text TenthScoreText;





    void Start()
    {
        kuki = FindObjectOfType<CamTimer>();
    }

    private void Awake() {
        entryContainer = transform.Find("highscoreEntryContainer");
        entryTemplate = entryContainer.Find("highscoreEntryTemplate");

        //entryTemplate.gameObject.SetActive(false);
        
        string jsonString = PlayerPrefs.GetString("CnCHCT");
        Highscores highscores = JsonUtility.FromJson<Highscores>(jsonString);

        if (highscores == null) {
            // There's no stored table, initialize
            Debug.Log("Initializing table with default values...");
            AddHighscoreEntry(1282786, "MRC");
            AddHighscoreEntry(1092642, "MRC");
            AddHighscoreEntry(992268, "TIM");
            AddHighscoreEntry(960288, "TIM");
            AddHighscoreEntry(861012, "TIM");
            AddHighscoreEntry(847648, "TIM");
            AddHighscoreEntry(805900, "MRC");
            AddHighscoreEntry(797264, "MRC");
            AddHighscoreEntry(504322, "MRC");
            AddHighscoreEntry(450522, "MRC");
            // Reload
            jsonString = PlayerPrefs.GetString("CnCHCT");
            highscores = JsonUtility.FromJson<Highscores>(jsonString);
        }

        // Sort entry list by Score
        for (int i = 0; i < highscores.highscoreEntryList.Count; i++) {
            for (int j = i + 1; j < highscores.highscoreEntryList.Count; j++) {
                if (highscores.highscoreEntryList[j].score > highscores.highscoreEntryList[i].score) {
                    // Swap
                    HighscoreEntry tmp = highscores.highscoreEntryList[i];
                    highscores.highscoreEntryList[i] = highscores.highscoreEntryList[j];
                    highscores.highscoreEntryList[j] = tmp;
                }
            }
        }

        FirstNameText.text = highscores.highscoreEntryList[0].name.ToString();
        FirstScoreText.text = highscores.highscoreEntryList[0].score.ToString();
        SecondNameText.text = highscores.highscoreEntryList[1].name.ToString();
        SecondScoreText.text = highscores.highscoreEntryList[1].score.ToString();
        ThirdNameText.text = highscores.highscoreEntryList[2].name.ToString();
        ThirdScoreText.text = highscores.highscoreEntryList[2].score.ToString();
        ForthNameText.text = highscores.highscoreEntryList[3].name.ToString();
        ForthScoreText.text = highscores.highscoreEntryList[3].score.ToString();
        FifthNameText.text = highscores.highscoreEntryList[4].name.ToString();
        FifthScoreText.text = highscores.highscoreEntryList[4].score.ToString();
        SixthNameText.text = highscores.highscoreEntryList[5].name.ToString();
        SixthScoreText.text = highscores.highscoreEntryList[5].score.ToString();
        SeventhNameText.text = highscores.highscoreEntryList[6].name.ToString();
        SeventhScoreText.text = highscores.highscoreEntryList[6].score.ToString();
        EightNameText.text = highscores.highscoreEntryList[7].name.ToString();
        EightScoreText.text = highscores.highscoreEntryList[7].score.ToString();
        NinethNameText.text = highscores.highscoreEntryList[8].name.ToString();
        NinethScoreText.text = highscores.highscoreEntryList[8].score.ToString();
        TenthNameText.text = highscores.highscoreEntryList[9].name.ToString();
        TenthScoreText.text = highscores.highscoreEntryList[9].score.ToString();


        /*
        highscoreEntryTransformList = new List<Transform>();
        foreach (HighscoreEntry highscoreEntry in highscores.highscoreEntryList) {
            CreateHighscoreEntryTransform(highscoreEntry, entryContainer, highscoreEntryTransformList);
        }
        */
    }

    private void CreateHighscoreEntryTransform(HighscoreEntry highscoreEntry, Transform container, List<Transform> transformList) {
        float templateHeight = 31f;
        Transform entryTransform = Instantiate(entryTemplate, container);
        RectTransform entryRectTransform = entryTransform.GetComponent<RectTransform>();
        entryRectTransform.anchoredPosition = new Vector2(0, -templateHeight * transformList.Count);
        entryTransform.gameObject.SetActive(true);

        int rank = transformList.Count + 1;
        string rankString;
        switch (rank) {
        default:
            rankString = rank + "TH"; break;

        case 1: rankString = "1ST"; break;
        case 2: rankString = "2ND"; break;
        case 3: rankString = "3RD"; break;
        }

        entryTransform.Find("posText").GetComponent<Text>().text = rankString;

        int score = highscoreEntry.score;

        entryTransform.Find("scoreText").GetComponent<Text>().text = score.ToString();

        string name = highscoreEntry.name;
        entryTransform.Find("nameText").GetComponent<Text>().text = name;

        // Set background visible odds and evens, easier to read
        entryTransform.Find("background").gameObject.SetActive(rank % 2 == 1);
        
        // Highlight First
        if (rank == 1) {
            entryTransform.Find("posText").GetComponent<Text>().color = Color.green;
            entryTransform.Find("scoreText").GetComponent<Text>().color = Color.green;
            entryTransform.Find("nameText").GetComponent<Text>().color = Color.green;
        }

        // Set tropy
        switch (rank) {
        default:
            entryTransform.Find("trophy").gameObject.SetActive(false);
            break;
        case 1:
            entryTransform.Find("trophy").GetComponent<Image>().color = UtilsClass.GetColorFromString("FFD200");
            break;
        case 2:
            entryTransform.Find("trophy").GetComponent<Image>().color = UtilsClass.GetColorFromString("C6C6C6");
            break;
        case 3:
            entryTransform.Find("trophy").GetComponent<Image>().color = UtilsClass.GetColorFromString("B76F56");
            break;

        }

        transformList.Add(entryTransform);
    }






    private void AddHighscoreEntry(int score, string name) {
        // Create HighscoreEntry
        HighscoreEntry highscoreEntry = new HighscoreEntry { score = score, name = name };
        
        // Load saved Highscores
        string jsonString = PlayerPrefs.GetString("CnCHCT");
        Highscores highscores = JsonUtility.FromJson<Highscores>(jsonString);

        if (highscores == null) {
            // There's no stored table, initialize
            highscores = new Highscores() {
                highscoreEntryList = new List<HighscoreEntry>()
            };
        }

        // Add new entry to Highscores
        highscores.highscoreEntryList.Add(highscoreEntry);

        // Save updated Highscores
        string json = JsonUtility.ToJson(highscores);
        PlayerPrefs.SetString("CnCHCT", json);
        PlayerPrefs.Save();
    }

    private class Highscores {
        public List<HighscoreEntry> highscoreEntryList;
    }

    /*
     * Represents a single High score entry
     * */
    [System.Serializable] 
    private class HighscoreEntry {
        public int score;
        public string name;
    }
    void Update()
    {
        if (kuki.hscRefresh == true)
        {
            
            kuki.hscRefresh = false;
            Destroy(entryTemplate);
            Awake();
        }
    }
}
